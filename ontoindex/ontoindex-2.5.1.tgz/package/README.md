# OntoIndex

**Graph-powered code intelligence for AI agents.** Index any codebase into a knowledge graph, then query it via MCP or CLI.

> Important: OntoIndex has no official cryptocurrency, token, or coin. Any token using the OntoIndex name is not affiliated with this project or its maintainers.

Works with **Cursor**, **Claude Code**, **Codex**, **Ontocode**, **Windsurf**, **Cline**, **OpenCode**, and any MCP-compatible tool.

[![npm version](https://img.shields.io/npm/v/ontoindex.svg)](https://www.npmjs.com/package/ontoindex)
[![License: AGPL-3.0-or-later](https://img.shields.io/badge/License-AGPL--3.0--or--later-blue.svg)](https://www.gnu.org/licenses/agpl-3.0.html)
[![GitHub](https://img.shields.io/badge/GitHub-ontograph%2Fontoindex-181717?logo=github)](https://github.com/ontograph/ontoindex)

- **Current release:** `2.1.3`
- **Repository:** [github.com/ontograph/ontoindex](https://github.com/ontograph/ontoindex)
- **Web UI:** [ontoindex.vercel.app](https://ontoindex.vercel.app)

---

## Why?

AI coding tools don't understand your codebase structure. They edit a function without knowing 47 other functions depend on it. OntoIndex fixes this by **precomputing every dependency, call chain, and relationship** into a queryable graph.

**Three commands to give your AI agent full codebase awareness.**

## Quick Start

```bash
# Index your repo (run from repo root)
npx ontoindex analyze

# Scope MCP setup to this repo by running setup here.
npx ontoindex setup
```

From a source checkout, install the latest GitHub release tarball with:

```bash
../scripts/install-ontoindex-latest.sh
```

That's it. This indexes the codebase, installs agent skills, registers Claude Code hooks, and creates the local editor context files the integrations need — all in one command.

To configure MCP for your editor, run `npx ontoindex setup` once — or set it up manually below.

`ontoindex setup` auto-detects your editors and writes the correct global MCP config. You only need to run it once.

### Editor Support

| Editor          | MCP | Skills | Hooks (auto-augment) | Support      |
| --------------- | --- | ------ | -------------------- | ------------ |
| **Claude Code** | Yes | Yes    | Yes (PreToolUse)     | **Full**     |
| **Cursor**      | Yes | Yes    | —                    | MCP + Skills |
| **Codex**       | Yes | Yes    | —                    | MCP + Skills |
| **Ontocode**    | Yes | Yes    | —                    | MCP + Skills |
| **Windsurf**    | Yes | —      | —                    | MCP          |
| **OpenCode**    | Yes | Yes    | —                    | MCP + Skills |

> **Claude Code** gets the deepest integration: MCP tools + agent skills + PreToolUse hooks that automatically enrich grep/glob/bash calls with knowledge graph context.

### Community Integrations

| Agent                | Install                       | Source                                                    |
| -------------------- | ----------------------------- | --------------------------------------------------------- |
| [pi](https://pi.dev) | `pi install npm:pi-ontoindex` | [pi-ontoindex](https://github.com/tintinweb/pi-ontoindex) |

## MCP Setup (manual)

If you prefer to configure manually instead of using `ontoindex setup`:

### Claude Code (full support — MCP + skills + hooks)

```bash
# macOS / Linux
claude mcp add ontoindex -- npx -y ontoindex@latest mcp

# Windows
claude mcp add ontoindex -- cmd /c npx -y ontoindex@latest mcp
```

### Codex (full support — MCP + skills)

```bash
codex mcp add ontoindex -- npx -y ontoindex@latest mcp
```

### Ontocode (Codex fork, full support — MCP + skills)

```bash
ontocode mcp add ontoindex -- npx -y ontoindex@latest mcp
```

### Cursor / Windsurf

Add to `~/.cursor/mcp.json` (global — works for all projects):

```json
{
  "mcpServers": {
    "ontoindex": {
      "command": "npx",
      "args": ["-y", "ontoindex@latest", "mcp"]
    }
  }
}
```

### OpenCode

Add to `~/.config/opencode/config.json`:

```json
{
  "mcp": {
    "ontoindex": {
      "command": "npx",
      "args": ["-y", "ontoindex@latest", "mcp"]
    }
  }
}
```

## How It Works

OntoIndex builds a complete knowledge graph of your codebase through a multi-phase indexing pipeline:

1. **Structure** — Walks the file tree and maps folder/file relationships
2. **Parsing** — Extracts functions, classes, methods, and interfaces using Tree-sitter ASTs
3. **Resolution** — Resolves imports and function calls across files with language-aware logic
   - **Field & Property Type Resolution** — Tracks field types across classes and interfaces for deep chain resolution (e.g., `user.address.city.getName()`)
   - **Return-Type-Aware Variable Binding** — Infers variable types from function return types, enabling accurate call-result binding
4. **Clustering** — Groups related symbols into functional communities
5. **Processes** — Traces execution flows from entry points through call chains
6. **Search** — Builds hybrid search indexes for fast retrieval

The result is a **LadybugDB graph database** stored locally in `.ontoindex/` with full-text search and semantic embeddings.

## MCP Tools

Your AI agent gets these tools automatically:

| Tool             | What It Does                                                     | `repo` Param |
| ---------------- | ---------------------------------------------------------------- | ------------ |
| `list_repos`     | Discover all indexed repositories                                | —            |
| `query`          | Process-grouped hybrid search (BM25 + semantic + RRF)            | Optional     |
| `context`        | 360-degree symbol view — categorized refs, process participation | Optional     |
| `impact`         | Blast radius analysis with depth grouping and confidence         | Optional     |
| `detect_changes` | Git-diff impact — maps changed lines to affected processes       | Optional     |
| `rename`         | Multi-file coordinated rename with graph + text search           | Optional     |
| `cypher`         | Raw Cypher graph queries                                         | Optional     |

> With one indexed repo, the `repo` param is optional. With multiple, specify which: `query({query: "auth", repo: "my-app"})`.

### Managed Freshness Recovery

`manage({action: 'ensure_fresh', repo})` is the prerequisite and managed-submission surface. With
`autoAnalyze: true`, it returns a structured submission status and either
queues or reuses work only when repository, target commit, source manifest,
requested graph or embedding capabilities, and analysis options match.

Observe a returned job ID with `manage({action: 'analyze_job', repo, jobId, job_action: 'status'})`. Its recovery disposition is
`REFRESH_RUNNING`, `REFRESHED`, `FAILED`, or `FRESHNESS_UNCONFIRMED`.
`REFRESHED` requires a job-bound publication receipt, the matching active
generation, and a final freshness check using the original capability
requirements. Exit code zero or job completion alone is not success proof.

Analysis locks are analyzer-owned. MCP clients and agents must never remove
`.ontoindex/analyze.lock`; retry the triggering graph operation unchanged only
after the terminal result is `REFRESHED`.

The stdio MCP server selects its project from `--project <path>` when supplied, then `ONTOINDEX_MCP_PROJECT_CWD`, then the git root of its working directory, or the working directory itself when it is outside a git repository. `ONTOINDEX_MCP_REPO` does not select the server project.

```bash
ONTOINDEX_MCP_PROJECT_CWD=/path/to/target/repo ontoindex mcp
ontoindex mcp --project /path/to/target/repo
```

`ontoindex mcp-doctor --repo <label-or-path> --project-cwd <path> --json` reports `READY`, `DEGRADED`, or `MISCONFIGURED`. `READY` means the target is configured; `DEGRADED` means it can run with a capability gap or a runtime/setup warning; `MISCONFIGURED` means the target or setup has a configuration mismatch. Optional `capabilityGaps` entries explain unavailable embeddings or language servers and informational runtime warnings. `processLiveness` reports servers bound by `--project` or by their working directory; several servers for one project are expected when separate client sessions start them. `setupHealth` checks editor setup, including `~/.agents/skills` only when `~/.codex/config.toml` or `~/.codex/hooks.json` exists; `ontoindex setup` creates the expected skills directory. The command exits with code 1 only for `MISCONFIGURED`.

## Environment Variables

- `ONTOINDEX_MCP_STARTUP_PROFILE` controls the advertised MCP tools. The default `core` profile lists only the 8 facades: `discover`, `search`, `inspect`, `impact`, `audit`, `refactor`, `manage`, and `docs`. Set it to `public-full` to list all 62 tools. Hidden legacy `gn_*` tools remain callable aliases.
- `ONTOINDEX_ALLOWED_HOSTS` adds trusted HTTP Host authorities for `serve` and `eval-server` (for example `localhost:8080` for a reverse proxy). Use up to 32 comma-separated hostnames or host:port authorities (IPv6 in brackets), each at most 255 characters. Hostnames are case-insensitive; host-only entries accept any port. Wildcards are unsupported; malformed entries are ignored with one stderr warning. Origin policy remains unchanged.
- `ONTOINDEX_MCP_IDLE_EXIT_MS` optionally exits the stdio MCP server after a period without requests or notifications; accepted values are `60000` through `86400000` milliseconds. Clients that do not restart a stopped stdio server will lose access to its tools, so leave this unset for those clients. The server does not exit while a repository connection pool is open; pools close after 5 minutes without a query. `manage({action: 'diagnose', repo})` reports `processMemory` for the running server.
- `ONTOINDEX_MAX_ARG_CHARS` limits string arguments accepted by MCP tools, REST `/api/search` and `/api/query`, and the eval server. It defaults to `2097152` characters and accepts values from `1024` through `67108864`.
- `ONTOINDEX_MAX_ARG_ITEMS` limits array arguments across tools; it defaults to `1024` items and accepts values from `1` through `65536`.
- `ONTOINDEX_MAX_ARG_TOTAL_BYTES` limits the UTF-8 size of serialized arguments; it defaults to the larger of `4194304` bytes or twice the string limit plus `1048576` bytes, and accepts values from `1024` through `134217728`.
- `ONTOINDEX_LBUG_BUFFER_MB` sets the read-only index connection's buffer pool size in MiB; it defaults to `64` and accepts `1` through `16384`. Unset, empty, `0`, or invalid values use the default: 64 MiB for the committed index and 256 MiB for working-tree graph generations (`overlay/<generation>`), which hold the whole repository and run the heaviest queries. A valid setting applies to both. In one run, a 64 MiB cap reduced resident memory after opening a 273 MiB index from about 426 MiB to 251 MiB, with queries about 10% slower.
- `ONTOINDEX_LBUG_POOL_SIZE` sets the per-repository read connection pool size; it defaults to `2` and accepts `1` through `16`.
- `ONTOINDEX_AUTO_WORKSPACE` controls automatic preparation of current workspace reads. An absent setting or exactly `1` enables it; `0`, an empty setting, or any other value disables it. Supported CLI and MCP reads prepare an immutable workspace generation when eligible source, configuration or base identity changes. Matching clean inputs reuse the committed index without a workspace build. Relationship reads use the full supported workspace graph; fresh lexical search has no new semantic vectors. Graph resources, lazy read tools, docs code facts and group reads share the preparation boundary. Diagnostics and explicit historical references retain their own scope. See [Working with uncommitted code](#working-with-uncommitted-code) for coverage and recovery.
- `ONTOINDEX_WORKSPACE_BUILD_TIMEOUT_MS` limits one supervised workspace build; the default is `120000` ms. The request preparation deadline is `60000` ms and covers capture and waiting. Cancelling one waiter does not cancel a shared build still needed by another waiter. Failed preparation returns its typed error; retry only where the response says the error is retryable.
- `ONTOINDEX_WORKSPACE_MAX_FILES` limits the indexed file count admitted to a full workspace build; the default is `1600`. A required graph above the limit returns `workspace_too_large`. To prepare a separate bounded workspace graph while preserving the committed index, explicitly run `ONTOINDEX_AUTO_WORKSPACE=1 ontoindex analyze --workspace-graph` in the repository, then rerun the read after workspace inputs change. An ordinary read does not substitute a stale committed success for failed required preparation. Benchmark runs that raise this gate must say so. Above the limit, `search` still sees uncommitted symbols through the symbols overlay when at most 50 source files changed and the base and resolver configuration are unchanged; relationship tools, `query` and `repomap` answer from the labelled committed index.

## Working with uncommitted code

For an explicit view of the indexed commit, add `read_mode: "committed"` and an
explicit repository to MCP `inspect/explore`, `inspect/context`, `impact/symbol`, or
`search/semantic`. This bypasses workspace preparation and excludes uncommitted
source, manual overlays and live LSP references. Responses include `readContext`
with indexed commit, generation, `sourceProvenance` (`commit`, `working-tree`, or
`unknown`), and `workingTreeIncluded` (`false`, `true`, or `null`). A committed
index analyzed from a dirty tree can include working-tree source, as these fields
report. Live or external enrichment options and repository groups are rejected.
Omission retains automatic workspace reads.
Repeat the same mode when following a pagination cursor.

Freshness `dirtyCoverage` describes symbol-overlay eligibility.
`workspaceReadiness.preparationChecked: false` means graph preparation has not
been checked. Size diagnostics use the file count stored in index metadata,
not an independently recounted filesystem total. Choose committed evidence when
current-worktree coverage is unnecessary. Increasing `ONTOINDEX_WORKSPACE_MAX_FILES`
permits more expensive full graph builds and requires suitable host resources.

Automatic reads capture eligible files from disk and pin one immutable generation
for graph queries and source enrichment. Matching generations are reused. The
capture is verified within finite retries; it is not an atomic filesystem
snapshot. Unsaved editor buffers and dynamic or external resolver inputs are
outside its coverage. Parse failures and unsupported capabilities remain explicit.

Logical pagination is bound to the admitted generation and input manifest; restart
the query when that binding changes. Saved response pages replay their original
bytes. Group reads prepare each repository independently and do not promise an
atomic snapshot across repositories. Read preparation preserves existing write
permissions and mutation guards.

Preparation failures return `workspace_busy`, `workspace_timeout`,
`workspace_cancelled`, `workspace_too_large` or `workspace_build_failed`.
Inspect the error and stderr before retrying; retry only when the response marks
the error retryable. A caller that expires before build admission starts no new
build. A build already admitted can finish for another waiter. Failed owned
captures are cleaned up; live readers retain their generation pins.

Set `ONTOINDEX_AUTO_WORKSPACE=0` to use committed/manual-overlay behavior.
`ontoindex analyze --dirty-overlay` and `ontoindex watch [path]` remain available
for manual operation; ordinary automatic reads require neither. Full workspace
graphs above the configured file gate fail explicitly. Adjust that gate only
for the available memory and CPU; the defaults and deadlines are listed above.

## Index Generations

`ontoindex clean --generations` prints a dry-run plan for obsolete index generations. It keeps the active generation and, by default, the two newest other generations, as well as generations with a live reader pin, incomplete generations, or generations while analysis is in progress. Add `--force` to delete eligible generations; `--keep <n>` sets the retained non-active generation count from `0` to `10` (default `2`), and `--all` applies the operation to every registered repository. A run deletes at most 50 generations. This mode never removes the active index or unregisters a repository. Generations created by older versions without a retention marker are eligible for cleanup only through this command.

## MCP Resources

| Resource                                 | Purpose                                              |
| ---------------------------------------- | ---------------------------------------------------- |
| `ontoindex://repos`                      | List all indexed repositories (read first)           |
| `ontoindex://repo/{name}/context`        | Codebase stats, staleness check, and available tools |
| `ontoindex://repo/{name}/clusters`       | All functional clusters with cohesion scores         |
| `ontoindex://repo/{name}/cluster/{name}` | Cluster members and details                          |
| `ontoindex://repo/{name}/processes`      | All execution flows                                  |
| `ontoindex://repo/{name}/process/{name}` | Full process trace with steps                        |
| `ontoindex://repo/{name}/schema`         | Graph schema for Cypher queries                      |

## MCP Prompts

| Prompt          | What It Does                                                              |
| --------------- | ------------------------------------------------------------------------- |
| `detect_impact` | Pre-commit change analysis — scope, affected processes, risk level        |
| `generate_map`  | Architecture documentation from the knowledge graph with mermaid diagrams |

## CLI Commands

```bash
ontoindex setup                   # Configure MCP for your editors (one-time)
ontoindex analyze [path]          # Index a repository (or update stale index)
ontoindex analyze --force         # Force full re-index
ontoindex analyze --embeddings    # Enable embedding generation (slower, better search)
ontoindex analyze --skip-agents-md  # Preserve custom AGENTS.md/CLAUDE.md ontoindex section edits
ontoindex analyze --verbose       # Log skipped files when parsers are unavailable
ontoindex mcp                     # Start MCP server (stdio) — serves all indexed repos
ontoindex serve                   # Start local HTTP server (multi-repo) for web UI
ontoindex index                   # Register an existing .ontoindex/ folder into the global registry
ontoindex list                    # List all indexed repositories
ontoindex status                  # Show index status for current repo
ontoindex clean                   # Delete index for current repo
ontoindex clean --all --force     # Delete all indexes
ontoindex wiki [path]             # Generate LLM-powered docs from knowledge graph
ontoindex wiki --model <model>    # Wiki with custom LLM model (default: gpt-4o-mini)
ontoindex mcp-doctor --repo <label-or-path> --project-cwd <path> --json  # Diagnose MCP target selection

# Repository groups (multi-repo / monorepo service tracking)
ontoindex group create <name>     # Create a repository group
ontoindex group add <name> <repo> # Add a repo to a group
ontoindex group remove <name> <repo> # Remove a repo from a group
ontoindex group list [name]       # List groups, or show one group's config
ontoindex group sync <name>       # Extract contracts and match across repos/services
ontoindex group contracts <name>  # Inspect extracted contracts and cross-links
ontoindex group query <name> <q>  # Search execution flows across all repos in a group
ontoindex group status <name>     # Check staleness of repos in a group
```

## Remote Embeddings

Set these env vars to use a remote OpenAI-compatible `/v1/embeddings` endpoint instead of the local model:

```bash
export ONTOINDEX_EMBEDDING_URL=http://your-server:8080/v1
export ONTOINDEX_EMBEDDING_MODEL=BAAI/bge-large-en-v1.5
export ONTOINDEX_EMBEDDING_DIMS=1024          # optional, default 384
export ONTOINDEX_EMBEDDING_API_KEY=your-key   # optional, default: "unused"
export ONTOINDEX_EMBEDDING_DOCUMENT_PREFIX="search_document: "  # optional, e.g. nomic-embed
export ONTOINDEX_EMBEDDING_QUERY_PREFIX="search_query: "        # optional
ontoindex analyze . --embeddings
```

Works with Infinity, vLLM, TEI, llama.cpp, Ollama, LM Studio, or OpenAI. When unset, local embeddings are used unchanged.

## Multi-Repo Support

OntoIndex supports indexing multiple repositories. Each `ontoindex analyze` registers the repo in a global registry (`~/.ontoindex/registry.json`). The MCP server serves all indexed repos automatically.

## Supported Languages

TypeScript, JavaScript, Python, Java, C, C++, C#, Go, Rust, PHP, Kotlin, Swift, Ruby

### Language Feature Matrix

| Language   | Imports | Named Bindings | Exports | Heritage | Type Annotations | Constructor Inference | Config | Frameworks | Entry Points |
| ---------- | ------- | -------------- | ------- | -------- | ---------------- | --------------------- | ------ | ---------- | ------------ |
| TypeScript | ✓       | ✓              | ✓       | ✓        | ✓                | ✓                     | ✓      | ✓          | ✓            |
| JavaScript | ✓       | ✓              | ✓       | ✓        | —                | ✓                     | ✓      | ✓          | ✓            |
| Python     | ✓       | ✓              | ✓       | ✓        | ✓                | ✓                     | ✓      | ✓          | ✓            |
| Java       | ✓       | ✓              | ✓       | ✓        | ✓                | ✓                     | —      | ✓          | ✓            |
| Kotlin     | ✓       | ✓              | ✓       | ✓        | ✓                | ✓                     | —      | ✓          | ✓            |
| C#         | ✓       | ✓              | ✓       | ✓        | ✓                | ✓                     | ✓      | ✓          | ✓            |
| Go         | ✓       | —              | ✓       | ✓        | ✓                | ✓                     | ✓      | ✓          | ✓            |
| Rust       | ✓       | ✓              | ✓       | ✓        | ✓                | ✓                     | —      | ✓          | ✓            |
| PHP        | ✓       | ✓              | ✓       | —        | ✓                | ✓                     | ✓      | ✓          | ✓            |
| Ruby       | ✓       | —              | ✓       | ✓        | —                | ✓                     | —      | ✓          | ✓            |
| Swift      | —       | —              | ✓       | ✓        | ✓                | ✓                     | ✓      | ✓          | ✓            |
| C          | —       | —              | ✓       | —        | ✓                | ✓                     | —      | ✓          | ✓            |
| C++        | —       | —              | ✓       | ✓        | ✓                | ✓                     | —      | ✓          | ✓            |

**Imports** — cross-file import resolution · **Named Bindings** — `import { X as Y }` / re-export tracking · **Exports** — public/exported symbol detection · **Heritage** — class inheritance, interfaces, mixins · **Type Annotations** — explicit type extraction for receiver resolution · **Constructor Inference** — infer receiver type from constructor calls (`self`/`this` resolution included for all languages) · **Config** — language toolchain config parsing (tsconfig, go.mod, etc.) · **Frameworks** — AST-based framework pattern detection · **Entry Points** — entry point scoring heuristics

## Agent Skills

OntoIndex ships with skill files that teach AI agents how to use the tools effectively:

- **Exploring** — Navigate unfamiliar code using the knowledge graph
- **Debugging** — Trace bugs through call chains
- **Impact Analysis** — Analyze blast radius before changes
- **Refactoring** — Plan safe refactors using dependency mapping

Installed automatically by both `ontoindex analyze` (per-repo) and `ontoindex setup` (global).

## Requirements

- Node.js >= 20
- Git repository (uses git for commit tracking)

## Release candidates

Stable releases publish to the default `latest` dist-tag. When a pull request
with non-documentation changes merges into `master`, an automated workflow also
publishes a prerelease build under the `rc` dist-tag, so early adopters can
try in-flight fixes without waiting for the next stable cut. (Docs-only
merges are skipped.)

```bash
# Try the latest release candidate (pre-stable — may change at any time)
npm install -g ontoindex@rc
# — or —
npx ontoindex@rc analyze
```

Release-candidate versions follow the standard semver prerelease format
`X.Y.Z-rc.N`, where `X.Y.Z` is the next stable target (bumped from the
current `latest` by patch by default; `minor` or `major` when kicking off a
bigger cycle) and `N` increments per published rc. Example sequence:
`1.9.1-rc.1`, `1.9.1-rc.2`, …, then once `1.9.1` ships stable, the next patch-cycle starts at
`1.9.2-rc.1` (or `1.10.0-rc.1` for a minor/bigger cycle). See the [Releases page](https://github.com/ontograph/ontoindex/releases)
for the full list; stable `latest` is unaffected.

## Troubleshooting

npm 11 blocks dependency install scripts; the installer passes `--allow-scripts=ontoindex,tree-sitter,@ladybugdb/core` for global installs, while project-local installs need an `allowScripts` field in `package.json`.

### `Cannot destructure property 'package' of 'node.target' as it is null`

This crash was caused by a dependency URL format that is incompatible with
certain npm/arborist versions ([npm/cli#8126](https://github.com/npm/cli/issues/8126)).
It is fixed in **ontoindex v1.9.0+**. Upgrade to the latest version:

```bash
npx ontoindex@latest analyze          # always uses the newest release
# — or —
npm install -g ontoindex@latest       # upgrade a global install
```

If you still hit npm install issues after upgrading, these generic workarounds
may help:

```bash
npm install -g npm@latest            # update npm itself
npm cache clean --force              # clear a possibly corrupt cache
```

### Optional native grammar build warnings

Some optional language grammars (Dart, Kotlin, Swift, Proto) require native
compilation. If an optional grammar fails to build, OntoIndex still installs and
continues to work; only that language's parsing support is skipped.

Local native build requirements:

- Node.js 20 LTS or 22 LTS
- npm with install scripts enabled
- Python 3
- `make`
- a C/C++ compiler (`g++` on Linux, Xcode command line tools on macOS)

If optional grammar build warnings appear:

```bash
# Ubuntu/Debian: sudo apt install python3 make g++
# macOS: xcode-select --install

npm install -g ontoindex
```

### Analysis runs out of memory

For very large repositories:

```bash
# Increase Node.js heap size
NODE_OPTIONS="--max-old-space-size=16384" npx ontoindex analyze

# Exclude large directories
echo "vendor/" >> .ontoindexignore
echo "dist/" >> .ontoindexignore
```

## Privacy

- All processing happens locally on your machine
- No code is sent to any server
- Index stored in `.ontoindex/` inside your repo (gitignored)
- Global registry at `~/.ontoindex/` stores only paths and metadata

## Web UI

OntoIndex also has a browser-based UI at [ontoindex.vercel.app](https://ontoindex.vercel.app) — 100% client-side, your code never leaves the browser.

**Local Backend Mode:** Run `ontoindex serve` and open the web UI locally — it auto-detects the server and shows all your indexed repos, with full AI chat support. No need to re-upload or re-index. The agent's tools (Cypher queries, search, code navigation) route through the backend HTTP API automatically.

## License

[GNU Affero General Public License v3.0 or later](https://www.gnu.org/licenses/agpl-3.0.html)
